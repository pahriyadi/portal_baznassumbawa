<?php
$iden = $this->model_utama->view_where('identitas', array('id_identitas' => 1))->row_array();
$logo = $this->model_utama->view_ordering_limit('logo', 'id_logo', 'DESC', 0, 1)->row_array();
?>

<div class="footer-modern-wrap">
    <div class="footer-info-content">
        <!-- 1. ABOUT -->
        <div class="footer-col-item">
            <img src="<?php echo base_url(); ?>asset/logo/<?php echo $logo['gambar']; ?>" alt="Logo" class="f-logo">
            <p class="f-text">BAZNAS Kabupaten Sumbawa mengelola Zakat, Infak, dan Sedekah secara profesional dan amanah.</p>
            <div class="f-social">
                <?php
                $sosmed_f = explode(",", $iden['facebook']);
                $fb = isset($sosmed_f[0]) ? trim(preg_replace('/\s+/', '', $sosmed_f[0])) : '#';
                $tw = isset($sosmed_f[1]) ? trim(preg_replace('/\s+/', '', $sosmed_f[1])) : '#';
                $ig = isset($sosmed_f[2]) ? trim(preg_replace('/\s+/', '', $sosmed_f[2])) : '#';
                $yt = isset($sosmed_f[3]) ? trim(preg_replace('/\s+/', '', $sosmed_f[3])) : '#';
                
                // Final sanitize to remove potential hidden characters/newlines
                $fb = str_replace(array("\r", "\n"), '', $fb);
                $tw = str_replace(array("\r", "\n"), '', $tw);
                $ig = str_replace(array("\r", "\n"), '', $ig);
                $yt = str_replace(array("\r", "\n"), '', $yt);
                ?>
                <a href="<?php echo $fb; ?>" target="_blank"><i class="fa fa-facebook"></i></a>
                <a href="<?php echo $ig; ?>" target="_blank"><i class="fa fa-instagram"></i></a>
                <a href="<?php echo $yt; ?>" target="_blank"><i class="fa fa-youtube-play"></i></a>
                <a href="<?php echo $tw; ?>" target="_blank"><i class="fa fa-twitter"></i></a>
            </div>
        </div>

        <!-- 2. TAUTAN PENTING -->
        <div class="footer-col-item" style="display: block !important; visibility: visible !important;">
            <h4 class="f-title">Tautan Penting</h4>
            <ul class="f-links" style="display: block !important; visibility: visible !important;">
                <li><a href="<?php echo base_url(); ?>"><i class="fa fa-angle-right"></i> Beranda</a></li>
                <li><a href="<?php echo base_url(); ?>halaman/detail/profil-organisasi"><i class="fa fa-angle-right"></i> Profil</a></li>
                <li><a href="<?php echo base_url(); ?>kalkulator-zakat"><i class="fa fa-angle-right"></i> Kalkulator Zakat</a></li>
                <li><a href="<?php echo base_url(); ?>laporan"><i class="fa fa-angle-right"></i> Laporan</a></li>
                <li><a href="<?php echo base_url(); ?>berita"><i class="fa fa-angle-right"></i> Berita</a></li>
            </ul>
        </div>

        <!-- 3. KONTAK -->
        <div class="footer-col-item">
            <h4 class="f-title">Kontak Kami</h4>
            <div class="f-contact-item">
                <i class="fa fa-map-marker"></i>
                <p><?php echo $iden['alamat']; ?></p>
            </div>
            <div class="f-contact-item">
                <i class="fa fa-phone"></i>
                <p><?php echo $iden['no_telp']; ?></p>
            </div>
            <div class="f-contact-item">
                <i class="fa fa-envelope"></i>
                <p><?php echo $iden['email']; ?></p>
            </div>
        </div>
    </div>
    
    <div class="footer-copy-bar">
        <p>&copy; <?php echo date('Y'); ?> <?php echo $iden['nama_website']; ?></p>
    </div>
</div>

<style>
    .footer-modern-wrap { background: var(--baznas-green); color: #fff; width: 100%; }
    .footer-info-content { padding: 40px 20px; display: grid; grid-template-columns: 1.5fr 1fr 1fr; gap: 30px; max-width: 1200px; margin: 0 auto; }
    .f-logo { background: #fff; padding: 10px; border-radius: 8px; max-height: 60px; margin-bottom: 20px; }
    .f-text { font-size: 14px; line-height: 1.6; color: rgba(255,255,255,0.9) !important; margin-bottom: 20px; }
    .f-title { color: var(--baznas-yellow) !important; font-size: 17px; font-weight: 700; margin-bottom: 20px; padding-bottom: 8px; border-bottom: 2px solid var(--baznas-yellow); display: inline-block; border-top:none !important; border-left:none !important; border-right:none !important; }
    .f-contact-item { display: flex; gap: 12px; margin-bottom: 12px; }
    .f-contact-item i { color: var(--baznas-yellow); font-size: 16px; margin-top: 2px; }
    .f-contact-item p { font-size: 13px; color: #fff !important; margin: 0; }
    .f-links { list-style: none; padding: 0; margin: 0; }
    .f-links li { margin-bottom: 8px; }
    .f-links li a { color: #fff !important; text-decoration: none; font-size: 14px; display: flex; align-items: center; gap: 8px; }
    .f-social { display: flex; gap: 10px; }
    .f-social a { width: 35px; height: 35px; background: rgba(255,255,255,0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff !important; }
    .footer-copy-bar { background: #004d28; padding: 15px; text-align: center; font-size: 11px; color: rgba(255,255,255,0.5); }

    @media (max-width: 991px) {
        .footer-info-content { grid-template-columns: 1fr !important; text-align: center; padding: 30px 20px 10px 20px !important; gap: 15px !important; }
        .footer-col-item { margin-bottom: 15px !important; display: flex !important; flex-direction: column; align-items: center; }
        .f-title { margin-bottom: 12px !important; font-size: 16px !important; }
        .f-contact-item { flex-direction: column; align-items: center; text-align: center; margin-bottom: 8px !important; }
        .f-links li a { justify-content: center; }
        .footer-modern-wrap { padding-bottom: 70px !important; margin-bottom: 0 !important; }
    }
</style>
<style>
    /* FINAL OVERRIDE - PLACED IN FOOTER FOR MAXIMUM PRIORITY */
    @media (max-width: 991px) {
        .modern-article-item img, 
        .ma-thumb, 
        .ma-thumb-lg,
        .modern-article-item > a img,
        .ma-img-wrapper img,
        .archive-thumb img,
        .rec-thumb-modern,
        .vid-thumb-wrapper img,
        .modern-article-item img.ma-thumb {
            width: 100% !important;
            height: 140px !important;
            min-height: 140px !important;
            max-height: 140px !important;
            object-fit: cover !important;
            display: block !important;
            float: none !important;
            margin: 0 !important;
            padding: 0 !important;
            border-radius: 0 !important;
        }
        
        .modern-article-item > a,
        .ma-img-wrapper,
        .archive-thumb,
        .vid-thumb-wrapper {
            width: 100% !important;
            height: 140px !important;
            display: block !important;
            float: none !important;
            background: #eee !important;
            border-radius: 0 !important;
            overflow: hidden !important;
        }

        .modern-article-item {
            flex-direction: column !important;
            gap: 0 !important;
        }

        .ma-content {
            width: 100% !important;
            padding: 12px !important;
            box-sizing: border-box !important;
        }
    }
</style>
