<div class="main-page left">
	<div class="double-block">
		<div class="content-block main right">
			<div class="block">
				<div class="featured-block">
					<?php
					$cekslide = $this->model_utama->view_single('berita', array('headline' => 'Y', 'status' => 'Y'), 'id_berita', 'DESC');
					if ($cekslide->num_rows() > 0) {
						include "slide.php";
					}
					?>
				</div>
			</div>

			<section class="modern-widget" aria-labelledby="latest-news-title">
				<div class="widget-header-modern">
					<h3 id="latest-news-title">Informasi Terbaru</h3>
				</div>
				<div class="modern-article-list">
					<?php
					$hot = $this->model_utama->view_join_two('berita', 'users', 'kategori', 'username', 'id_kategori', array('status' => 'Y'), 'tanggal', 'DESC', 0, 5);
					foreach ($hot->result_array() as $row):
						$total_komentar = $this->model_utama->view_where('komentar', array('id_berita' => $row['id_berita']))->num_rows();
						$isi_berita = strip_tags($row['isi_berita']);
						$isi = substr($isi_berita, 0, 150) . '...';
						$thumb = (!empty($row['gambar'])) ? base_url() . "asset/foto_berita/$row[gambar]" : base_url() . "asset/foto_berita/small_no-image.jpg";
						?>
						<article class="modern-article-item">
							<a href="<?php echo base_url() . $row['judul_seo']; ?>" class="ma-img-wrapper"
								aria-label="<?php echo $row['judul']; ?>">
								<img src="<?php echo $thumb; ?>" loading="lazy" class="ma-thumb-lg"
									alt="<?php echo $row['judul']; ?>" title="<?php echo $row['judul']; ?>">
							</a>
							<div class="ma-content">
								<header>
									<a href="<?php echo base_url() . "kategori/detail/$row[kategori_seo]"; ?>"
										class="cat-pill"><?php echo $row['nama_kategori']; ?></a>
									<h4><a
											href="<?php echo base_url() . $row['judul_seo']; ?>"><?php echo $row['judul']; ?></a>
									</h4>
								</header>
								<div class="ma-meta">
									<time datetime="<?php echo $row['tanggal']; ?>">📅
										<?php echo tgl_indo($row['tanggal']); ?></time>
									<span>🕒 <?php echo $row['jam']; ?></span>
									<span>💬 <?php echo $total_komentar; ?></span>
								</div>
								<p class="ma-excerpt"><?php echo $isi; ?></p>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
				<div class="widget-footer-modern">
					<a href="<?php echo base_url(); ?>berita/indeks_berita" class="more-pill">Lihat Lebih Banyak</a>
				</div>
			</section>

			<!-- Widget Video Terbaru -->
			<section class="modern-widget" aria-labelledby="latest-video-title">
				<div class="widget-header-modern">
					<h3 id="latest-video-title">Video Terbaru</h3>
				</div>
				<div class="modern-grid-card">
					<?php
					$q_vid = $this->db->query("SELECT * FROM video ORDER BY id_video DESC LIMIT 6");
					foreach ($q_vid->result_array() as $v):
						$yt_id = '';
						if (preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $v['youtube'], $match)) {
							$yt_id = $match[1];
						}
						$t_img = ($yt_id != '') ? "https://img.youtube.com/vi/{$yt_id}/mqdefault.jpg" : base_url() . "asset/foto_berita/no-image.jpg";
						?>
						<article class="vid-card-item">
							<a href="<?php echo base_url() . "playlist/watch/$v[video_seo]"; ?>"
								aria-label="<?php echo $v['jdl_video']; ?>">
								<div class="vid-thumb-wrapper">
									<img src="<?php echo $t_img; ?>" loading="lazy" alt="<?php echo $v['jdl_video']; ?>" title="<?php echo $v['jdl_video']; ?>">
									<div class="play-btn-overlay">
										<svg viewBox="0 0 24 24">
											<path d="M8 5v14l11-7z" />
										</svg>
									</div>
								</div>
								<h4 class="vid-title"><?php echo $v['jdl_video']; ?></h4>
							</a>
						</article>
					<?php endforeach; ?>
				</div>
				<div class="widget-footer-modern">
					<a href="<?php echo base_url(); ?>playlist" class="more-pill">Semua Video</a>
				</div>
			</section>

			<?php
			$ia = $this->model_utama->view_where_ordering_limit('iklantengah', array('posisi' => 'home'), 'id_iklantengah', 'ASC', 0, 1)->row_array();
			if ($ia):
				echo "<a href='$ia[url]' target='_blank' style='display:block; margin-bottom: 25px;'>";
				$string = $ia['gambar'];
				if ($ia['gambar'] != '') {
					if (preg_match("/swf\z/i", $string)) {
						echo "<embed src='" . base_url() . "asset/foto_iklantengah/$ia[gambar]' width='100%' height='90' quality='high' type='application/x-shockwave-flash'>";
					} else {
						echo "<img loading='lazy' width='100%' src='" . base_url() . "asset/foto_iklantengah/$ia[gambar]' title='$ia[judul]' alt='$ia[judul]' style='border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);' />";
					}
				}
				echo "</a>";
			endif;
			?>

			<!-- Widget Berita Pilihan -->
			<section class="modern-widget" aria-labelledby="featured-news-title">
				<div class="widget-header-modern">
					<h3 id="featured-news-title">Berita Pilihan BAZNAS</h3>
				</div>
				<div class="modern-article-list">
					<?php
					$pilihan = $this->model_utama->view_join_two('berita', 'users', 'kategori', 'username', 'id_kategori', array('berita.aktif' => 'Y', 'berita.status' => 'Y'), 'tanggal', 'DESC', 0, 5);
					foreach ($pilihan->result_array() as $pi):
						$thumb = (!empty($pi['gambar'])) ? base_url() . "asset/foto_berita/$pi[gambar]" : base_url() . "asset/foto_berita/small_no-image.jpg";
						?>
						<article class="modern-article-item">
							<a href="<?php echo base_url() . $pi['judul_seo']; ?>" class="ma-img-wrapper"
								aria-label="<?php echo $pi['judul']; ?>">
								<img src="<?php echo $thumb; ?>" loading="lazy" class="ma-thumb-lg"
									alt="<?php echo $pi['judul']; ?>" title="<?php echo $pi['judul']; ?>">
							</a>
							<div class="ma-content">
								<header>
									<a href="<?php echo base_url() . "kategori/detail/$pi[kategori_seo]"; ?>"
										class="cat-pill"><?php echo $pi['nama_kategori']; ?></a>
									<h4><a
											href="<?php echo base_url() . $pi['judul_seo']; ?>"><?php echo $pi['judul']; ?></a>
									</h4>
								</header>
								<div class="ma-meta">
									<time datetime="<?php echo $pi['tanggal']; ?>">📅
										<?php echo tgl_indo($pi['tanggal']); ?></time>
								</div>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
				<div class="widget-footer-modern">
					<a href="<?php echo base_url(); ?>berita/indeks_berita" class="more-pill">Indeks Berita</a>
				</div>
			</section>

			<!-- Widget Foto Galeri -->
			<section class="modern-widget" aria-labelledby="gallery-title">
				<div class="widget-header-modern">
					<h3 id="gallery-title">Galeri Foto</h3>
				</div>
				<div class="modern-grid-card gallery">
					<?php
					$q_foto = $this->db->query("SELECT g.jdl_gallery, g.gbr_gallery, a.album_seo FROM gallery g JOIN album a ON g.id_album=a.id_album ORDER BY g.id_gallery DESC LIMIT 6");
					foreach ($q_foto->result_array() as $f):
						$f_img = (!empty($f['gbr_gallery'])) ? base_url() . "asset/img_galeri/$f[gbr_gallery]" : base_url() . "asset/foto_berita/no-image.jpg";
						?>
						<a href="<?php echo base_url() . "albums/detail/$f[album_seo]"; ?>" class="gallery-item-card"
							aria-label="<?php echo $f['jdl_gallery']; ?>">
							<img src="<?php echo $f_img; ?>" loading="lazy" alt="<?php echo $f['jdl_gallery']; ?>" title="<?php echo $f['jdl_gallery']; ?>">
							<div class="gallery-overlay">
								<span><?php echo substr($f['jdl_gallery'], 0, 20); ?>...</span>
							</div>
						</a>
					<?php endforeach; ?>
				</div>
				<div class="widget-footer-modern">
					<a href="<?php echo base_url(); ?>albums" class="more-pill">Lihat Galeri</a>
				</div>
			</section>

			<!-- Widget Rekomendasi BAZNAS (Random News) -->
			<section class="modern-widget" aria-labelledby="random-news-title">
				<div class="widget-header-modern">
					<h3 id="random-news-title">Rekomendasi BAZNAS</h3>
				</div>
				<div class="modern-article-list">
					<?php
					$random = $this->db->query("SELECT * FROM berita a JOIN kategori b ON a.id_kategori=b.id_kategori WHERE a.status='Y' ORDER BY RAND() LIMIT 5");
					foreach ($random->result_array() as $r):
						$thumb = (!empty($r['gambar'])) ? base_url() . "asset/foto_berita/$r[gambar]" : base_url() . "asset/foto_berita/small_no-image.jpg";
						?>
						<article class="modern-article-item">
							<a href="<?php echo base_url() . $r['judul_seo']; ?>" class="ma-img-wrapper">
								<img src="<?php echo $thumb; ?>" loading="lazy" class="ma-thumb-lg"
									alt="<?php echo $r['judul']; ?>" title="<?php echo $r['judul']; ?>">
							</a>
							<div class="ma-content">
								<header>
									<a href="<?php echo base_url() . "kategori/detail/$r[kategori_seo]"; ?>"
										class="cat-pill"><?php echo $r['nama_kategori']; ?></a>
									<h4><a href="<?php echo base_url() . $r['judul_seo']; ?>"><?php echo $r['judul']; ?></a>
									</h4>
								</header>
								<div class="ma-meta">
									<time datetime="<?php echo $r['tanggal']; ?>">📅
										<?php echo tgl_indo($r['tanggal']); ?></time>
								</div>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
				<div class="widget-footer-modern">
					<a href="<?php echo base_url(); ?>berita" class="more-pill">Semua Berita</a>
				</div>
			</section>


		</div>
		<div class="content-block left hidden-xs">
			<?php include "sidebar_kiri.php"; ?>
		</div>
	</div>
</div>
<div class="main-sidebar right hidden-xs">
	<?php include "sidebar_kanan.php"; ?>
</div>
<div style="clear: both; height: 1px;"></div>

<!-- Widget Iklan Tengah Grid -->
<section class="modern-widget ad-row"
	style="background: transparent; border: none; box-shadow: none; padding: 0; margin-top: 20px;">
	<div class="modern-grid-card" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
		<?php
		$advetorial = $this->model_utama->view_where_ordering_limit('iklantengah', array('posisi' => 'home_tengah'), 'id_iklantengah', 'ASC', 0, 6);
		foreach ($advetorial->result_array() as $row):
			$img_src = base_url() . "asset/foto_iklantengah/$row[gambar]";
			?>
			<div class="ad-card-item">
				<a href="<?php echo $row['url']; ?>" target="_blank" class="ad-link-modern">
					<?php if (preg_match("/swf\z/i", $row['gambar'])): ?>
						<embed src="<?php echo $img_src; ?>" width="100%" height="90" quality="high"
							type="application/x-shockwave-flash">
					<?php else: ?>
						<img src="<?php echo $img_src; ?>" loading="lazy" alt="<?php echo $row['judul']; ?>"
							class="ad-img-modern">
					<?php endif; ?>
				</a>
			</div>
		<?php endforeach; ?>
	</div>
</section>

<?php /* End of polished content */ ?>