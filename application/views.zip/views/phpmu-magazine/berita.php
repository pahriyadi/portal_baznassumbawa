<div class="main-content">
	<div class="main-page left">
		<div class="double-block">
			<div class="content-block main left">
				<div class="block">
					<div class="block-title" style="background: #2182b4;">
						<a href="<?php echo base_url(); ?>" class="right">Back to homepage</a>
						<h2><?php echo $title; ?></h2>
					</div>
					<div class="block-content">
						<div class="modern-article-list">
							<?php
							foreach ($berita->result_array() as $r) {
								$baca = $r['dibaca'] + 1;
								$isi_berita = strip_tags($r['isi_berita']);
								$isi = substr($isi_berita, 0, 220);
								$space_pos = strrpos($isi, " ");
								if ($space_pos !== false) {
									$isi = substr($isi_berita, 0, $space_pos);
								}
								$judul = $r['judul'];
								$total_komentar = $this->model_utama->view_where('komentar', array('id_berita' => $r['id_berita']))->num_rows();

								echo "<div class='modern-article-item'>
                                                            <div class='ma-img-wrapper'>
                                                                <a href='" . base_url() . "$r[judul_seo]'>";
								if ($r['gambar'] == '') {
									echo "<img src='" . base_url() . "asset/foto_berita/no-image.jpg' alt='$r[judul]' title='$r[judul]' />";
								} else {
									echo "<img src='" . base_url() . "asset/foto_berita/$r[gambar]' alt='$r[judul]' title='$r[judul]' />";
								}
								echo "</a>
                                                            </div>
                                                            <div class='ma-content'>
                                                                <h4><a title='$r[judul]' href='" . base_url() . "$r[judul_seo]'>$judul</a></h4>
                                                                <div class='ma-meta hidden-xs'>
                                                                    <span style='color: var(--baznas-green); font-weight: 600;'>$r[nama_kategori]</span>
                                                                    <span>&#128340; " . tgl_indo($r['tanggal']) . "</span>
                                                                </div>
                                                            </div>
                                                        </div>";
							}
							?>
						</div>
						<div class="pagination">
							<?php echo $this->pagination->create_links(); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="content-block right">
				<?php include "sidebar_kiri.php"; ?>
			</div>
		</div>
	</div>
	<div class="main-sidebar right">
		<?php include "sidebar_kanan.php"; ?>
	</div>
	<div class="clear-float"></div>
</div>